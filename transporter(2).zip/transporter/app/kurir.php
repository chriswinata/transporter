<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class kurir extends Model
{
    protected $guarded = [];
}
