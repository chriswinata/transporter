<?php

namespace App\Http\Controllers;

use App\kurir;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class KurirController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $kurirs = kurir::paginate(10);

        return response()->json([
            'message' => 'success',
            'data' => $kurirs,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $kurir = kurir::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->passsword),
        ]);

        return response()->json([
            'message' => 'kurir berhasil dibuat',
            'data' => $kurir,
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\kurir  $kurir
     * @return \Illuminate\Http\Response
     */
    public function show(kurir $kurir)
    {
        return response()->json([
            'message' => 'succcess',
            'data' => $kurir,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\kurir  $kurir
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, kurir $kurir)
    {
        $kurir->name = $request->name;
        $kurir->email = $request->email;
        $kurir->password = Hash::make($request->password);
        $kurir->save();
        return response()->json([
            'message' => 'kurir berhasil di update',
            'data' => $kurir
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\kurir  $kurir
     * @return \Illuminate\Http\Response
     */
    public function destroy(kurir $kurir)
    {
        $kurir->delete();
        return response()->json([
            'message' => 'Kurir berhasil dihapus'
        ], 204);
    }
}
