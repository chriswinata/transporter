<?php

use App\Http\Controllers\BarangController;
use App\Http\Controllers\KurirController;
use App\Http\Controllers\LokasiController;
use App\Http\Controllers\PengirimanController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::prefix('kurirs')->name('kurirs.')->group(function() {
    Route::get('index', [KurirController::class, 'index']);
    Route::post('create', [KurirController::class, 'store']);
    Route::get('show/{kurir}', [KurirController::class, 'show']);
    Route::put('update/{kurir}', [KurirController::class, 'update']);
    Route::delete('delete/{kurir}', [KurirController::class, 'destroy']);
});

Route::prefix('barangs')->name('barangs.')->group(function() {
    Route::get('index', [BarangController::class, 'index']);
    Route::post('create', [BarangController::class, 'store']);
    Route::get('show/{kurir}', [BarangController::class, 'show']);
    Route::put('update/{kurir}', [BarangController::class, 'update']);
    Route::delete('delete/{kurir}', [BarangController::class, 'destroy']);
});

Route::prefix('lokasis')->name('lokasis.')->group(function() {
    Route::get('index', [LokasiController::class, 'index']);
    Route::post('create', [LokasiController::class, 'store']);
    Route::get('show/{kurir}', [LokasiController::class, 'show']);
    Route::put('update/{kurir}', [LokasiController::class, 'update']);
    Route::delete('delete/{kurir}', [LokasiController::class, 'destroy']);
});

Route::prefix('pengirimans')->name('pengirimans.')->group(function () {
    Route::post('submit', [PengirimanController::class, 'submit']);
    Route::post('approval', [PengirimanController::class, 'apporval']);
});