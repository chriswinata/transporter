<?php

namespace App\Http\Controllers;

use App\lokasi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class LokasiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $lokasis = lokasi::paginate(10);

        return response()->json([
            'message' => 'success',
            'data' => $lokasis,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $lokasi = lokasi::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->passsword),
        ]);

        return response()->json([
            'message' => 'lokasi berhasil dibuat',
            'data' => $lokasi,
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\lokasi  $lokasi
     * @return \Illuminate\Http\Response
     */
    public function show(lokasi $lokasi)
    {
        return response()->json([
            'message' => 'succcess',
            'data' => $lokasi,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\lokasi  $lokasi
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, lokasi $lokasi)
    {
        $lokasi->name = $request->name;
        $lokasi->email = $request->email;
        $lokasi->password = Hash::make($request->password);
        $lokasi->save();
        return response()->json([
            'message' => 'lokasi berhasil di update',
            'data' => $lokasi
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\lokasi  $lokasi
     * @return \Illuminate\Http\Response
     */
    public function destroy(lokasi $lokasi)
    {
        $lokasi->delete();
        return response()->json([
            'message' => 'lokasi berhasil dihapus'
        ], 204);
    }
}
