<?php

namespace App\Http\Controllers;

use App\barang;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class BarangController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $barangs = barang::paginate(10);

        return response()->json([
            'message' => 'success',
            'data' => $barangs,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $barang = barang::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->passsword),
        ]);

        return response()->json([
            'message' => 'barang berhasil dibuat',
            'data' => $barang,
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\barang  $barang
     * @return \Illuminate\Http\Response
     */
    public function show(barang $barang)
    {
        return response()->json([
            'message' => 'succcess',
            'data' => $barang,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\barang  $barang
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, barang $barang)
    {
        $barang->name = $request->name;
        $barang->email = $request->email;
        $barang->password = Hash::make($request->password);
        $barang->save();
        return response()->json([
            'message' => 'barang berhasil di update',
            'data' => $barang
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\barang  $barang
     * @return \Illuminate\Http\Response
     */
    public function destroy(barang $barang)
    {
        $barang->delete();
        return response()->json([
            'message' => 'barang berhasil dihapus'
        ], 204);
    }
}
